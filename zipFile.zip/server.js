const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);

app.use(express.static('public'));

let equipos = [
    { id: 'eq1', nombre: 'Equipo Rojo', ocupado: false, bonos: ['Bloqueo 10s', 'Puntos x2'], bloqueado: false },
    { id: 'eq2', nombre: 'Equipo Azul', ocupado: false, bonos: ['Bloqueo 10s'], bloqueado: false },
    { id: 'eq3', nombre: 'Equipo Verde', ocupado: false, bonos: ['Bloqueo 10s'], bloqueado: false }
];

let estadoJuego = {
    vistaActual: 'espera',
    pulsadorActivo: false,
    colaPulsador: [],
    bloqueoGlobal: false
};

io.on('connection', (socket) => {
    socket.emit('init_data', { equipos, estadoJuego });

    socket.on('unirse_equipo', (idEquipo) => {
        const equipo = equipos.find(e => e.id === idEquipo);
        if (equipo && !equipo.ocupado) {
            equipo.ocupado = true;
            socket.equipoId = idEquipo;
            io.emit('actualizar_equipos', equipos);
        }
    });

    socket.on('pulsar_boton', () => {
        const equipo = equipos.find(e => e.id === socket.equipoId);
        if (estadoJuego.pulsadorActivo && !estadoJuego.bloqueoGlobal && !equipo.bloqueado) {
            const yaPulso = estadoJuego.colaPulsador.find(p => p.id === equipo.id);
            if (!yaPulso) {
                estadoJuego.colaPulsador.push({ id: equipo.id, nombre: equipo.nombre, tiempo: Date.now() });
                io.emit('actualizar_estado', estadoJuego);
            }
        }
    });

    socket.on('admin_cambiar_escena', (escena) => {
        estadoJuego.vistaActual = escena;
        io.emit('actualizar_estado', estadoJuego);
    });

    socket.on('admin_control_pulsador', (accion) => {
        if (accion === 'abrir') estadoJuego.pulsadorActivo = true;
        if (accion === 'pausar') estadoJuego.pulsadorActivo = false;
        if (accion === 'reset') {
            estadoJuego.pulsadorActivo = false;
            estadoJuego.colaPulsador = [];
        }
        io.emit('actualizar_estado', estadoJuego);
    });

    socket.on('admin_bloquear_equipo', (data) => {
        const equipo = equipos.find(e => e.id === data.idEquipo);
        if (equipo) {
            equipo.bloqueado = data.bloquear;
            io.emit('actualizar_equipos', equipos);
        }
    });

    socket.on('admin_bloqueo_global', (estado) => {
        estadoJuego.bloqueoGlobal = estado;
        io.emit('actualizar_estado', estadoJuego);
    });
    
    socket.on('disconnect', () => {
        if (socket.equipoId) {
            const equipo = equipos.find(e => e.id === socket.equipoId);
            if(equipo) equipo.ocupado = false;
            io.emit('actualizar_equipos', equipos);
        }
    });
});

http.listen(process.env.PORT || 3000, () => {
    console.log('Servidor listo');
});